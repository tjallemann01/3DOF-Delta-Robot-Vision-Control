clc; clear;

% Mensaje inicial para indicar que se ejecutará la cinemática inversa del robot Delta
fprintf('--- CINEMÁTICA INVERSA COMPLETA PARA ROBOT DELTA DE 3 DOF ---\n');

% === PARÁMETROS DEL ROBOT ===

l1 = 0.232       ; % l1: Longitud del eslabón actuado (desde motor hasta junta intermedia)
l2 = 0.450       ; % l2: Longitud del eslabón pasivo (del paralelogramo)
rho_B = 0.1125   ; % rho_B: Distancia vertical desde la base hasta el eje del motor
rho_P = 0.040    ; % rho_P: Distancia desde la plataforma móvil hasta el punto de unión con el eslabón pasivo

% === POSICIÓN OBJETIVO ===
% Coordenadas deseadas del efector final (punto central de la plataforma móvil)
xo = 0.00000; 
yo = 0.00000; 
zo = -0.25117;
P_obj = [xo; yo; zo];  % Vector columna con la posición deseada

% === Mostrar PARAMETROS DEL ROBOT y POSICIÓN OBJETIVO ===

fprintf("\nParámetros cargados correctamente.\n");
fprintf("\nl1 = %.4f m, l2 = %.4f m, rhoB = %.4f m, rhoP = %.4f m, \n", ...
        l1, l2, rho_B, rho_P);
fprintf("Posición del efector final Oef: x = %.5f, y = %.5f, z = %.5f\n\n", xo, yo, zo);

% Arreglo para almacenar los ángulos θ1, θ2, θ3 para cada brazo
theta = zeros(1, 3);

fprintf('\n========== INICIANDO CÁLCULOS PARA CADA BRAZO ==========\n\n');

% Bucle para calcular cada brazo (hay 3 brazos en un robot Delta)
for i = 1:3
    fprintf('--- Brazo %d ---\n', i);

    % Cálculo del ángulo de rotación alrededor del eje Z para el brazo i
    angle_deg = (i - 1) * 120;
    angle_rad = deg2rad(angle_deg);
    Rz = [cos(angle_rad), -sin(angle_rad), 0;
          sin(angle_rad),  cos(angle_rad), 0;
          0, 0, 1];  % Matriz de rotación en Z

    % Rotación del objetivo al sistema de coordenadas del brazo i
    P_rot = Rz * P_obj;
    x = P_rot(1); y = P_rot(2); z = P_rot(3);

    % Coordenada del punto P1 (unión de eslabón pasivo con plataforma)
    P1 = [xo; y - rho_P; z];
    fprintf('P1 respecto a base (sistema %d°): %s\n', angle_deg, mat2str(P1', 4));
    
    P1 = [0; y - rho_P; z];
    fprintf('Proyección P1'' en plano YZ: %s\n', mat2str(P1', 4));

    % Cálculo del radio φ (phi), usado como radio del círculo C2
    phi = sqrt(l2^2 - x^2);
    fprintf('Radio φ del círculo C2 = %.4f\n', phi);

    % Coordenadas del centro del círculo C1 (en la base)
    B = [0; -rho_B; 0];

    % Coordenadas del centro del círculo C2 (en la plataforma)
    C = [0; y - rho_P; z];

    fprintf('Centro de C1: %s\n', mat2str(B', 4));
    fprintf('Centro de C2: %s\n', mat2str(C', 4));

    % Intersección de los dos círculos en el plano YZ usando simbología
    syms yB zB
    eq1 = (yB + rho_B)^2 + zB^2 == l1^2;  % Círculo C1
    eq2 = (yB - (y - rho_P))^2 + (zB - z)^2 == phi^2;  % Círculo C2
    sol = solve([eq1, eq2], [yB, zB], 'Real', true);  % Resolver el sistema

    % Convertir soluciones simbólicas a valores numéricos
    ysol = double(sol.yB); 
    zsol = double(sol.zB);

    % Validar si hay solución real
    if isempty(ysol)
        error('❌ No hay solución real para el brazo %d.', i);
    end

    % Elegir la solución con menor valor de y (por convención o diseño)
    if ysol(1) < ysol(2)
        yj = ysol(1); 
        zj = zsol(1);
    else
        yj = ysol(2); 
        zj = zsol(2);
    end

    % Coordenada del punto de intersección Pj
    Pj = [0; yj; zj];
    fprintf('Intersección Pj con menor Y: %s\n', mat2str(Pj', 4));

    % Cálculo del ángulo θi usando función atan2
    theta_i = atan2(zj, B(2) - yj);
    theta(i) = rad2deg(theta_i);
    fprintf('Ángulo θ%d = %.2f°\n\n', i, theta(i));

    %% === GRÁFICA DE VALIDACIÓN EN PLANO YZ ===
    figure(100+i); clf; hold on; axis equal; grid on;
    title(sprintf('Validación geométrica - Brazo %d (YZ rotado %d°)', i, angle_deg));
    xlabel('y'); ylabel('z');

    % Dibujar el círculo C1
    theta_circ = linspace(0, 2*pi, 300);
    yC1 = l1 * cos(theta_circ) - rho_B;
    zC1 = l1 * sin(theta_circ);
    plot(yC1, zC1, 'b--', 'LineWidth', 1.5);
    scatter(-rho_B, 0, 50, 'b', 'filled');
    text(-rho_B + 0.005, 0.01, 'B_i');

    % Dibujar el círculo C2
    yc2 = y - rho_P; 
    zc2 = z;
    yC2 = phi * cos(theta_circ) + yc2;
    zC2 = phi * sin(theta_circ) + zc2;
    plot(yC2, zC2, 'r--', 'LineWidth', 1.5);
    scatter(yc2, zc2, 50, 'r', 'filled');
    text(yc2 + 0.005, zc2 + 0.01, 'P_i''');

    % Dibujar el punto de intersección Pj
    scatter(yj, zj, 60, 'k', 'filled');
    text(yj + 0.005, zj - 0.015, 'P_{ji}');

    % Dibujar los eslabones: l1 y phi
    plot([-rho_B yj], [0 zj], 'k-', 'LineWidth', 2);     % Eslabón l1
    plot([yj yc2], [zj zc2], 'r-', 'LineWidth', 2);      % Eslabón phi

    % Leyenda de la figura
    legend({'Círculo C_1', 'Centro C_1 (B_i)', ...
            'Círculo C_2', 'Centro C_2 (P_i'')', ...
            'Intersección P_{ji}', 'l_1', '\phi'}, ...
           'Location', 'bestoutside');
end

%% === RESULTADOS FINALES ===
% Imprimir los ángulos finales obtenidos para los tres brazos
fprintf('\n========== RESULTADOS FINALES ==========\n');
fprintf('Ángulos calculados para alcanzar el objetivo:\n');
fprintf('θ1 = %.2f°\n', theta(1));
fprintf('θ2 = %.2f°\n', theta(2));
fprintf('θ3 = %.2f°\n', theta(3));

%% === DESCRIPCIÓN FINAL DE LAS GRÁFICAS ===
fprintf('\n--- DESCRIPCIÓN DE LAS GRÁFICAS MOSTRADAS ---\n');
fprintf('Cada figura muestra el análisis geométrico en el plano YZ rotado correspondiente a cada brazo.\n');
fprintf('Se representan dos círculos:\n');
fprintf('1) Círculo C1 (azul punteado) centrado en el punto B_i, con radio l1.\n');
fprintf('2) Círculo C2 (rojo punteado) centrado en el punto proyectado P_i'', con radio φ.\n');
fprintf('La intersección de estos dos círculos determina el punto P_{ji}, donde se articula el eslabón intermedio.\n');
fprintf('Las líneas negras y rojas representan los eslabones físicos l1 y φ, respectivamente.\n');
fprintf('Estas gráficas validan visualmente que la solución obtenida para θ_i es geométricamente coherente.\n');
