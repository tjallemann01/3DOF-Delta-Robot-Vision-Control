clc;
clear;

fprintf("=== Análisis de Cinemática Directa – Robot Delta 3DOF ===\n\n");

%% Paso 1: Ingresar datos geométricos
fprintf("Paso 1: Definición de parámetros geométricos del robot.\n");
l1 = 0.232                       ; %Ingrese la longitud del brazo actuado l1 (m)
l2 = 0.450                       ; % Ingrese la longitud del eslabón pasivo l2 (m)
rhoB = 0.1125                    ; % Ingrese la distancia vertical desde la base hasta el brazo: rhoB (m)
rhoP = 0.040                     ; % Ingrese la distancia vertical desde la plataforma móvil hasta el punto de unión: rhoP (m)

theta_1 = 25.37                 ; % Theta1 (en grados)
theta_2 = 25.37                  ; % Theta2 (en grados)
theta_3 = 25.37                  ; % Theta3 (en grados)

theta1 = deg2rad(theta_1)        ; % Ingrese el ángulo theta1 (en grados)
theta2 = deg2rad(theta_2)        ; % Ingrese el ángulo theta2 (en grados)
theta3 = deg2rad(theta_3)        ; % Ingrese el ángulo theta3 (en grados)
rhoDelta = rhoB - rhoP           ;

fprintf("\nParámetros cargados correctamente.\n");
fprintf("l1 = %.4f m, l2 = %.4f m, rhoB = %.4f m, rhoP = %.4f m, rhoDelta = %.4f m\n", ...
        l1, l2, rhoB, rhoP, rhoDelta);
fprintf("\nÁngulos ingresados (en grados): θ1 = %.4f, θ2 = %.4f, θ3 = %.4f\n", theta_1, theta_2, theta_3);

%% Paso 2: Calcular posición de los puntos P'Ji en SCB1
fprintf("\nPaso 2: Cálculo de las coordenadas de los puntos P'Ji (transformados a SCB1).\n");

% Coordenadas de P'J1 en SCB1
x1 = 0;
y1 = -rhoB - l1 * cos(theta1) + rhoP;
z1 = l1 * sin(theta1);

fprintf("\nP'J1 = [%.4f, %.4f, %.4f] (en SCB1)\n", x1, y1, z1);

% Rotaciones de ±120°
Rz120 = [cosd(120), -sind(120), 0; sind(120), cosd(120), 0; 0, 0, 1];
Rz_120 = [cosd(-120), -sind(-120), 0; sind(-120), cosd(-120), 0; 0, 0, 1];

% P'J2 en su sistema local, luego rotado a SCB1
pj2_local = [0; -rhoDelta - l1*cos(theta2); l1*sin(theta2)];
pj2 = Rz120 * pj2_local;
x2 = pj2(1); 
y2 = pj2(2); 
z2 = pj2(3);

fprintf("P'J2 = [%.4f, %.4f, %.4f] (rotado a SCB1 +120°)\n", x2, y2, z2);

% P'J3 en su sistema local, luego rotado a SCB1
pj3_local = [0; -rhoDelta - l1*cos(theta3); l1*sin(theta3)];
pj3 = Rz_120 * pj3_local;
x3 = pj3(1); 
y3 = pj3(2); 
z3 = pj3(3);

fprintf("P'J3 = [%.4f, %.4f, %.4f] (rotado a SCB1 -120°)\n", x3, y3, z3);

%% Paso 3: Definir ecuaciones de esferas
fprintf("\nPaso 3: Formulación de las ecuaciones de las esferas centradas en los puntos P'Ji.\n");
fprintf("\nCada esfera tiene radio igual a l2 = %.4f m\n", l2);

% Ecuaciones de las esferas:
% (x - xi)^2 + (y - yi)^2 + (z - zi)^2 = l2^2

% Aquí se resuelve el sistema usando resta de ecuaciones para eliminar términos cuadráticos

syms x y z

eq1 = (x - x1)^2 + (y - y1)^2 + (z - z1)^2 == l2^2;
eq2 = (x - x2)^2 + (y - y2)^2 + (z - z2)^2 == l2^2;
eq3 = (x - x3)^2 + (y - y3)^2 + (z - z3)^2 == l2^2;

fprintf("Se ha construido el sistema de ecuaciones de intersección de 3 esferas .\n");
fprintf("\nEcuación de la esfera 1:\n");
fprintf("(x - %.4f)^2 + (y - %.4f)^2 + (z - %.4f)^2 = %.4f^2\n", x1, y1, z1, l2);

fprintf("\nEcuación de la esfera 2:\n");
fprintf("(x - %.4f)^2 + (y - %.4f)^2 + (z - %.4f)^2 = %.4f^2\n", x2, y2, z2, l2);

fprintf("\nEcuación de la esfera 3:\n");
fprintf("(x - %.4f)^2 + (y - %.4f)^2 + (z - %.4f)^2 = %.4f^2\n", x3, y3, z3, l2);


%% Paso 4: Resolución del sistema de ecuaciones
fprintf("\nPaso 4: Resolviendo el sistema para encontrar el punto de intersección (posición del efector final).\n");

sol = solve([eq1, eq2, eq3], [x, y, z]);

% Convertimos las soluciones a números
x_sol = double(sol.x);
y_sol = double(sol.y);
z_sol = double(sol.z);

% En caso de múltiples soluciones, tomar la de z menor
[~, idx] = min(z_sol);
x_final = x_sol(idx);
y_final = y_sol(idx);
z_final = z_sol(idx);

%% Resultado final
fprintf("\n=== Resultado Final ===\n");
fprintf("\nCoordenadas del efector final (Oef):\n");
fprintf("x = %.5f m\n", x_final);
fprintf("y = %.5f m\n", y_final);
fprintf("z = %.5f m\n", z_final);
