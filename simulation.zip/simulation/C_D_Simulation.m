clc;
clear;

fprintf("=== Análisis de Cinemática Directa – Robot Delta 3DOF ===\n\n");

%% Paso 1: Ingresar datos geométricos
fprintf("Paso 1: Definición de parámetros geométricos del robot.\n");
l1 = 0.232                     ; % Ingrese la longitud del brazo actuado l1 (m)
l2 = 0.450                     ; % Ingrese la longitud del eslabón pasivo l2 (m)
rhoB = 0.1125                  ; % Ingrese la altura desde la base hasta la articulación (rhoB) (m)
rhoP = 0.040                   ; % Ingrese la altura desde la plataforma móvil hasta la rótula (rhoP) (m)

theta_1 = 25.37                  ; % Theta1 (en grados)
theta_2 = 25.37                  ; % Theta2 (en grados)
theta_3 = 25.37                  ; % Theta3 (en grados)

theta1 = deg2rad(theta_1)        ; % Ingrese el ángulo theta1 (en grados)
theta2 = deg2rad(theta_2)        ; % Ingrese el ángulo theta2 (en grados)
theta3 = deg2rad(theta_3)        ; % Ingrese el ángulo theta3 (en grados)

rhoDelta = rhoB - rhoP;

fprintf("\nResultado paso 1: Parámetros cargados correctamente.\n");
fprintf("\nl1 = %.4f m, l2 = %.4f m, rhoB = %.4f m, rhoP = %.4f m, rhoDelta = %.4f m\n", ...
        l1, l2, rhoB, rhoP, rhoDelta);
fprintf("Ángulos ingresados (en grados): θ1 = %.4f, θ2 = %.4f, θ3 = %.4f\n\n", theta_1, theta_2, theta_3);

%% Paso 2: Calcular puntos P'Ji en SCB1
fprintf("Paso 2: Cálculo de coordenadas de los puntos P'Ji en el sistema base.\n");

x1 = 0;
y1 = -rhoB - l1 * cos(theta1) + rhoP;
z1 = l1 * sin(theta1);

fprintf("\nP'J1 = [%.4f, %.4f, %.4f] (en SCB1)\n", x1, y1, z1);

Rz120 = [cosd(120), -sind(120), 0; sind(120), cosd(120), 0; 0, 0, 1];
Rz_120 = [cosd(-120), -sind(-120), 0; sind(-120), cosd(-120), 0; 0, 0, 1];

pj2_local = [0; -rhoDelta - l1*cos(theta2); l1*sin(theta2)];
pj2 = Rz120 * pj2_local;
x2 = pj2(1); y2 = pj2(2); z2 = pj2(3);
fprintf("P'J2 = [%.4f, %.4f, %.4f] (rotado a SCB1 +120°)\n", x2, y2, z2);

pj3_local = [0; -rhoDelta - l1*cos(theta3); l1*sin(theta3)];
pj3 = Rz_120 * pj3_local;
x3 = pj3(1); y3 = pj3(2); z3 = pj3(3);
fprintf("P'J3 = [%.4f, %.4f, %.4f] (rotado a SCB1 -120°)\n\n", x3, y3, z3);

%% Paso 3: Definir esferas
fprintf("Paso 3: Formulación de las ecuaciones de las esferas centradas en P'Ji.\n");
fprintf("\nRadio de cada esfera = l2 = %.4f m\n", l2);

syms x y z

eq1 = (x - x1)^2 + (y - y1)^2 + (z - z1)^2 == l2^2;
eq2 = (x - x2)^2 + (y - y2)^2 + (z - z2)^2 == l2^2;
eq3 = (x - x3)^2 + (y - y3)^2 + (z - z3)^2 == l2^2;

fprintf("Resultado paso 3: Sistema de 3 ecuaciones cuadráticas listo para resolución.\n\n");
fprintf("\nEcuación de la esfera 1:\n");
fprintf("(x - %.4f)^2 + (y - %.4f)^2 + (z - %.4f)^2 = %.4f^2\n", x1, y1, z1, l2);

fprintf("\nEcuación de la esfera 2:\n");
fprintf("(x - %.4f)^2 + (y - %.4f)^2 + (z - %.4f)^2 = %.4f^2\n", x2, y2, z2, l2);

fprintf("\nEcuación de la esfera 3:\n");
fprintf("(x - %.4f)^2 + (y - %.4f)^2 + (z - %.4f)^2 = %.4f^2\n", x3, y3, z3, l2);

%% Paso 4: Resolver el sistema
fprintf("\nPaso 4: Resolviendo el sistema de ecuaciones para encontrar el efector final.\n");

sol = solve([eq1, eq2, eq3], [x, y, z]);
x_sol = double(sol.x);
y_sol = double(sol.y);
z_sol = double(sol.z);

[~, idx] = min(z_sol);
x_final = x_sol(idx);
y_final = y_sol(idx);
z_final = z_sol(idx);

fprintf("\nSoluciones posibles:\n");
for i = 1:length(x_sol)
    fprintf("Solución %d: x = %.4f, y = %.4f, z = %.4f\n", i, x_sol(i), y_sol(i), z_sol(i));
end

fprintf("\nSelección final: Se eligió la solución con menor valor en z (más baja físicamente).\n");

%% Resultado final
fprintf("\n=== Resultado Final – Posición del efector final Oef ===\n");
fprintf("\nx = %.5f m\n", x_final);
fprintf("y = %.5f m\n", y_final);
fprintf("z = %.5f m\n\n", z_final);

%% Simulación gráfica 3D
fprintf("Generando simulación gráfica 3D...\n");

figure;
hold on; grid on; axis equal;
xlabel('X (m)'); ylabel('Y (m)'); zlabel('Z (m)');
title('Simulación Cinemática Directa Robot Delta 3DOF');

% Dibujar esferas
[xx, yy, zz] = sphere(30);
surf(l2*xx + x1, l2*yy + y1, l2*zz + z1, 'FaceAlpha', 0.1, 'EdgeColor', 'none', 'FaceColor', 'r');
surf(l2*xx + x2, l2*yy + y2, l2*zz + z2, 'FaceAlpha', 0.1, 'EdgeColor', 'none', 'FaceColor', 'g');
surf(l2*xx + x3, l2*yy + y3, l2*zz + z3, 'FaceAlpha', 0.1, 'EdgeColor', 'none', 'FaceColor', 'b');

% Dibujar puntos P'Ji
plot3(x1, y1, z1, 'ro', 'MarkerSize', 8, 'DisplayName', 'P''J1');
plot3(x2, y2, z2, 'go', 'MarkerSize', 8, 'DisplayName', 'P''J2');
plot3(x3, y3, z3, 'bo', 'MarkerSize', 8, 'DisplayName', 'P''J3');

% Dibujar efector final
plot3(x_final, y_final, z_final, 'kp', 'MarkerSize', 10, 'MarkerFaceColor', 'k', 'DisplayName', 'Oef');

% Dibujar líneas de brazos pasivos
line([x1 x_final], [y1 y_final], [z1 z_final], 'Color', 'r', 'LineWidth', 2);
line([x2 x_final], [y2 y_final], [z2 z_final], 'Color', 'g', 'LineWidth', 2);
line([x3 x_final], [y3 y_final], [z3 z_final], 'Color', 'b', 'LineWidth', 2);

% Dibujar brazos actuados
B1 = [0; -rhoB; 0];
B2 = Rz120 * B1;
B3 = Rz_120 * B1;
line([B1(1) x1], [B1(2) y1], [B1(3) z1], 'Color', 'k', 'LineStyle', '--');
line([B2(1) x2], [B2(2) y2], [B2(3) z2], 'Color', 'k', 'LineStyle', '--');
line([B3(1) x3], [B3(2) y3], [B3(3) z3], 'Color', 'k', 'LineStyle', '--');

legend show;
view(35, 25);

%% Descripción final
fprintf("\n=== DESCRIPCIÓN DE LA SIMULACIÓN ===\n");
fprintf("La figura generada representa el análisis de cinemática directa del robot Delta.\n");
fprintf("Cada esfera representa la posible ubicación del efector final desde uno de los brazos pasivos.\n");
fprintf("La intersección de las tres esferas determina la posición única del efector final (Oef).\n");
fprintf("Se muestran los brazos actuados (líneas punteadas) y los eslabones pasivos (líneas sólidas).\n");
fprintf("El punto negro en la figura es el efector final, calculado geométricamente.\n");
