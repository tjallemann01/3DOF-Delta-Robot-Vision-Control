clc;
clear;

fprintf('=== VERIFICADOR DE ÁREA DE TRABAJO PARA ROBOT DELTA DE 3 DOF ===\n\n');

% === PARÁMETROS GEOMÉTRICOS DEL ROBOT DELTA ===
l1 = 0.232;     % Longitud del brazo actuado (m)
l2 = 0.450;     % Longitud del brazo pasivo (m)
rho_B = 0.1125; % Altura base fija a articulación (m)
rho_P = 0.040;  % Altura plataforma móvil a la unión (m)

% === AJUSTE DE ALTURA Z (opcional) ===
% Esta variable compensa diferencias entre el sistema de referencia del robot
% y el sistema de medición externa (por ejemplo, cámara o mesa).
% Si no necesitas ajustar Z, déjalo en 0.
Z_CUSTOM = 0;

% === GENERACIÓN DE NUBE DE PUNTOS PARA VISUALIZAR WORKSPACE ===
fprintf('Calculando volumen de trabajo estimado...\n');
[xg, yg, zg] = meshgrid(-0.3:0.03:0.3, -0.3:0.03:0.3, -0.65:0.03:-0.1);
workspace = false(size(xg));

for idx = 1:numel(xg)
    x = xg(idx);
    y = yg(idx);
    z = zg(idx);
    z_ajustada = z + Z_CUSTOM;
    valido = true;

    for i = 0:2
        alpha = deg2rad(i * 120);
        x_rot = cos(alpha) * x + sin(alpha) * y;
        z_rot = z_ajustada;
        A = x_rot;
        B = z_rot - rho_B + rho_P;
        D = (A^2 + B^2 - l1^2 - l2^2) / (2 * l1 * l2);
        if abs(D) > 1
            valido = false;
            break;
        end
    end
    workspace(idx) = valido;
end

% Mostrar área de trabajo estimada
figure('Name', 'Área de Trabajo del Robot Delta');
scatter3(xg(workspace), yg(workspace), zg(workspace), 10, [0.6 0.6 0.6], 'filled');
xlabel('X [m]');
ylabel('Y [m]');
zlabel('Z [m]');
title('Workspace del Robot Delta');
grid on;
axis equal;
hold on;

% === BUCLE INTERACTIVO ===
while true
    % Solicitar coordenadas al usuario
    fprintf('\n--- INGRESA COORDENADAS A VERIFICAR ---\n');
    x = input('Coordenada X [m]: ');
    y = input('Coordenada Y [m]: ');
    z = input('Coordenada Z [m]: ');

    % Aplicar ajuste en Z
    z_ajustada = z + Z_CUSTOM;
    dentro = true;

    try
        for i = 0:2
            alpha = deg2rad(i * 120);
            x_rot = cos(alpha) * x + sin(alpha) * y;
            z_rot = z_ajustada;
            A = x_rot;
            B = z_rot - rho_B + rho_P;
            D = (A^2 + B^2 - l1^2 - l2^2) / (2 * l1 * l2);
            if abs(D) > 1
                dentro = false;
                break;
            end
        end
    catch
        dentro = false;
    end

    % Mostrar resultado en texto
    if dentro
        fprintf('\n✅ El punto (%.3f, %.3f, %.3f) ESTÁ dentro del área de trabajo.\n', x, y, z);
        plot3(x, y, z, 'go', 'MarkerSize', 10, 'LineWidth', 2); % Punto verde
    else
        fprintf('\n❌ El punto (%.3f, %.3f, %.3f) está FUERA del área de trabajo.\n', x, y, z);
        plot3(x, y, z, 'ro', 'MarkerSize', 10, 'LineWidth', 2); % Punto rojo
    end

    % Preguntar si desea continuar
    continuar = input('\n¿Deseas probar otro punto? (s/n): ', 's');
    if lower(continuar) ~= 's'
        fprintf('\nFinalizando verificación...\n');
        break;
    end
end

hold off;
