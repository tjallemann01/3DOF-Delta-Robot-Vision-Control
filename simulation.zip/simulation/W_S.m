clc;
clear;

fprintf('=== VERIFICADOR DE ÁREA DE TRABAJO PARA ROBOT DELTA DE 3 DOF ===\n\n');

% === PARÁMETROS GEOMÉTRICOS DEL ROBOT ===
l1 = 0.232;     % Longitud del brazo actuado (m)
l2 = 0.450;     % Longitud del brazo pasivo (m)
rho_B = 0.1125; % Distancia vertical de la base al punto rotacional (m)
rho_P = 0.040;  % Distancia vertical de la plataforma al punto esférico (m)

% === AJUSTE EN EL EJE Z ===
% En muchos robots Delta, el sistema de coordenadas donde defines los puntos
% (por ejemplo: una cámara o una mesa) no coincide con el sistema de referencia
% usado en la cinemática inversa (que suele partir del centro de la base del robot).
% Esta variable permite ajustar esa diferencia vertical.
% Si mides Z desde la mesa y tu robot tiene su origen 18 cm por encima, debes compensar eso:
Z_CUSTOM = 0;  % ← Desfase vertical en metros (ajústalo según tu sistema físico)

% === BUCLE PRINCIPAL ===
while true
    % --- Ingreso de coordenadas ---
    fprintf('\n--- INGRESA COORDENADAS A VERIFICAR ---\n');
    x = input('Coordenada X [m]: ');
    y = input('Coordenada Y [m]: ');
    z = input('Coordenada Z [m]: ');

    % --- Aplicar el ajuste Z si es necesario ---
    z_ajustada = z + Z_CUSTOM;

    % --- Bandera para verificar si el punto es alcanzable ---
    dentro = true;

    try
        % Verificar si hay solución de cinemática inversa en los 3 brazos
        for i = 0:2
            % Ángulo del brazo i respecto al eje Y (0°, 120°, 240°)
            alpha = deg2rad(i * 120);

            % Rotación del sistema global al local del brazo i
            x_rot = cos(alpha) * x + sin(alpha) * y;
            z_rot = z_ajustada;

            % Ecuación para obtener si existe un ángulo válido
            A = x_rot;
            B = z_rot - rho_B + rho_P;

            % Verificar si existe solución real (D ∈ [-1, 1])
            D = (A^2 + B^2 - l1^2 - l2^2) / (2 * l1 * l2);

            if abs(D) > 1
                dentro = false;
                break;  % No es necesario continuar con los otros brazos
            end
        end
    catch
        dentro = false;
    end

    % --- Resultado ---
    if dentro
        fprintf('\n✅ El punto (%.3f, %.3f, %.3f) ESTÁ dentro del área de trabajo.\n', x, y, z);
    else
        fprintf('\n❌ El punto (%.3f, %.3f, %.3f) está FUERA del área de trabajo.\n', x, y, z);
    end

    % --- Pregunta para continuar ---
    continuar = input('\n¿Deseas probar otro punto? (s/n): ', 's');
    if lower(continuar) ~= 's'
        fprintf('\nFinalizando verificación...\n');
        break;
    end
end