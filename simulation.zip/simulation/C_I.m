clc; clear;

fprintf('--- CINEMÁTICA INVERSA COMPLETA PARA ROBOT DELTA DE 3 DOF ---\n');

%% === INGRESO DE PARÁMETROS ===
l1 = 0.232           ; % Longitud del eslabón 1 (l1)
l2 = 0.450           ; % Longitud del eslabón 2 (l2)
rho_B = 0.1125       ; % Altura de la base fija a la articulación rotacional (rho_B)
rho_P = 0.040        ; % Altura de la plataforma móvil a la articulación esférica (rho_P) 

xo = 0.00000         ; % Coordenada X del efector final
yo = 0.00000         ; % Coordenada Y del efector final
zo = -0.25117        ; % Coordenada Z del efector final

P_obj = [xo; yo; zo]  ;

fprintf("\nParámetros cargados correctamente.\n");
fprintf("\nl1 = %.4f m, l2 = %.4f m, rhoB = %.4f m, rhoP = %.4f m, \n", ...
        l1, l2, rho_B, rho_P);
fprintf("Posición del efector final Oef: x = %.5f, y = %.5f, z = %.5f\n\n", xo, yo, zo);

fprintf('\n========== INICIANDO CÁLCULOS PARA CADA BRAZO ==========\n\n');

theta = zeros(1, 3);

for i = 1:3
    fprintf('--- Brazo %d ---\n', i);

    % Rotar el sistema según el brazo
    angle_deg = (i - 1) * 120; % 0°, 120°, 240°
    angle_rad = deg2rad(angle_deg);

    % Matriz de rotación en Z
    Rz = [cos(angle_rad), -sin(angle_rad), 0;
          sin(angle_rad),  cos(angle_rad), 0;
          0,               0,              1];

    % Transformar punto objetivo al sistema rotado
    P_rot = Rz * P_obj;

    x = P_rot(1);
    y = P_rot(2);
    z = P_rot(3);

    % Paso 1: P1 rotado respecto a base
    P1 = [xo; y - rho_P; z];
    fprintf('P1 respecto a base (sistema %d°): %s\n', angle_deg, mat2str(P1', 4));

    % Paso 2: Proyección P1 sobre plano YZ (x = 0)
    P1_proj = [0; y - rho_P; z];
    fprintf('Proyección P1'' en plano YZ: %s\n', mat2str(P1_proj', 4));

    % Paso 3: Radio del círculo C2
    phi = sqrt(l2^2 - x^2);
    fprintf('Radio φ del círculo C2 = %.4f\n', phi);

    % Paso 4: Centros de los círculos
    B = [0; -rho_B; 0];             % Centro de C1
    C = [0; y - rho_P; z];          % Centro de C2
    fprintf('Centro de C1: %s\n', mat2str(B', 4));
    fprintf('Centro de C2: %s\n', mat2str(C', 4));

    % Paso 5: Intersección de los círculos en YZ
    syms yB zB
    eq1 = (yB + rho_B)^2 + zB^2 == l1^2;
    eq2 = (yB - (y - rho_P))^2 + (zB - z)^2 == phi^2;

    sol = solve([eq1, eq2], [yB, zB], 'Real', true);

    ysol = double(sol.yB);
    zsol = double(sol.zB);

    if isempty(ysol)
        error('No hay solución real para el brazo %d. Revisa los parámetros.', i);
    end

    if ysol(1) < ysol(2)
        yj = ysol(1);
        zj = zsol(1);
    else
        yj = ysol(2);
        zj = zsol(2);
    end

    Pj = [0; yj; zj];
    fprintf('Intersección Pj con menor Y: %s\n', mat2str(Pj', 4));

    % Paso 6: Calcular ángulo θ
    theta_i = atan2(zj, B(2) - yj);
    theta(i) = rad2deg(theta_i);
    fprintf('Ángulo θ%d = %.2f°\n\n', i, theta(i));
end

fprintf('========== RESULTADOS FINALES ==========\n');
fprintf('θ1 = %.2f°\n', theta(1));
fprintf('θ2 = %.2f°\n', theta(2));
fprintf('θ3 = %.2f°\n', theta(3));
